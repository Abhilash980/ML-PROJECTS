# Indian Sign Language Recognition (PRAICP-1000)

An image-classification project that recognises Indian Sign Language hand-sign classes using transfer learning.

## Workflow
- Discover image-class directories and build an image inventory.
- Explore class distribution, image dimensions, color modes, and duplicate images.
- Split the data into stratified training, validation, and test sets.
- Resize images to 224 × 224, convert to RGB, and augment training images.
- Train a MobileNetV2 transfer-learning baseline and fine-tune selected layers.
- Evaluate with accuracy, precision, recall, F1-score, a classification report, and confusion matrix.
- Provide a single-image prediction function and save model artifacts.

## Dataset
The notebook uses the official DataMites PRAICP-1000 IndiSignLang image dataset. Place or extract the dataset under the `data/` folder beside the notebook, preserving the class-folder structure. The dataset is not included in this repository.

## Tools
Python, TensorFlow/Keras, NumPy, pandas, Matplotlib, Pillow, and scikit-learn.

## Run
Open `PRAICP-1000_IndiSign_Language_Recognition.ipynb` in Jupyter or Google Colab, install the imported dependencies, configure the dataset folder if needed, and run the cells in order. Notebook outputs were cleared for publication; evaluation results are generated when the notebook is executed.

## Notebook
[Open the project notebook](./PRAICP-1000_IndiSign_Language_Recognition.ipynb)
