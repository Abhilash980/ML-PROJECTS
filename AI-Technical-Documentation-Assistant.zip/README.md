# AI-Powered Technical Documentation & Support Assistant

A Retrieval-Augmented Generation (RAG) chatbot that answers questions using Python technical documentation PDFs.

## RAG workflow
PDF documents → PyPDF loading → recursive text chunking → Hugging Face embeddings → ChromaDB vector store → MMR retrieval → Groq-hosted LLM → grounded answer with source/page information.

## Technology stack
Python, LangChain, PyPDF, Hugging Face `all-MiniLM-L6-v2` embeddings, ChromaDB, Groq, Streamlit, and python-dotenv.

## Setup
1. Place the Python documentation PDFs under `data/raw/`.
2. Create a `.env` file in the project folder and set `GROQ_API_KEY` to your own Groq API key. Never commit the `.env` file.
3. Install the notebook's imported dependencies.
4. Open `AI-Client-Project-5.ipynb` in Jupyter or Google Colab and run the cells in order.
5. Set `BUILD_VECTOR_STORE = True` only when you need to build or rebuild the ChromaDB vector store.

The PDFs and API credentials are not included in this repository. Notebook outputs were cleared for publication.

## Notebook
[Open the project notebook](./AI-Client-Project-5.ipynb)
